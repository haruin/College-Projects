#ifndef _GRAFO_H
#define _GRAFO_H

#include "Lista2.h"
#include "NodoBETA2HD.h"

class Grafo{
    friend class Lista< Nodo >;
    friend class Elemento< Nodo >;
public:
    Grafo(): graf(){}
    ~Grafo() {graf.BorrarLista();}
    Grafo(const Grafo &G) {*this = G;}
    Grafo &operator=(const Grafo &G)
    {
        if(this!=&G){ 
            graf = G.graf;
        }
        return *this;
    }
    /*
    void Agregar(int N)
    {
        //Nodo A(N);
        graf.Insertar(N);   
    }*/
    
    void Agregar(Nodo N) 
    {
        cout<<"m8\n";
        if(!graf.Buscar(N))
            graf.Insertar(N);
    }
    
    void Quitar(Nodo N)
    {
        if(graf.Buscar(N))
            graf.Eliminar(N);
    }
    //void Unir(Nodo, Nodo );
    void Unir(int, int);
    void Imprimir() {graf.Imprimir();}
private:
    Lista< Nodo > graf;  
    //Lista< Nodo > aristas;
    //int numNodo;
};

//******************************************************************************

void Grafo::Unir(int A, int B)
{
    //Nodo orig(A), dest(B);
    Elemento<Nodo> *aux = graf.Primero, *temp = graf.Primero;
    while(aux->valor!=A){
        aux = aux->Sig;
    }  
    cout<<aux->valor;
    while(temp->valor!=B){
        temp = temp->Sig;
    }    
    
    Nodo orig(A), dest(B);
    aux.insArista(dest);
    //cout<<aux->valor<<endl;
    //Nodo hee = aux->valor;
    //hee.Sig = B;
    //Arista dest(B);
    //cout<<dest;
    //Arista *orig = new Arista(A), *dest = new Arista(B);
    //aux->valor.InsertarArista(B);
    //aux->valor.aristas->Insertar(dest);
    //temp->valor.aristas->Insertar(orig);
    //aux->valor.Sig = beta;
    //temp->valor.Sig = aux->valor;
}


/*
void Grafo::Unir(Nodo A, Nodo B)
{
    Elemento<Nodo> *aux = graf.Primero, *temp = graf.Primero;
    while(aux->valor!=A.valor){
        aux = aux->Sig;
    }  
    cout<<aux->valor.Sig<<endl;
    while(temp->valor!=B.valor){
        temp = temp->Sig;
    }    
    //cout<<aux->valor<<endl;
    //Nodo hee = aux->valor;
    //hee.Sig = B;
    aux->valor.Sig = B.Sig;
  //  temp->valor.Sig = A;
}
*/
//******************************************************************************
#endif
