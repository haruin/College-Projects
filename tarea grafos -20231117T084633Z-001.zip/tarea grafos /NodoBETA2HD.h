#ifndef _NODO_H
#define _NODO_H

#include "Arista.h"
#include "Lista.h"

//template<class Tipo> class Lista; 
//template<class Tipo>
class Nodo{
  //  friend class Lista;
    friend class Grafo;
    friend istream & operator>>(istream &CIN,Nodo &N)
    {
        cout<<">Dame el valor del Nodo: ";
        CIN>>N.valor;
        //Primero = N;
    }
    friend ostream & operator<<(ostream &COUT, Nodo &N)
    {
        COUT<<"["<<N.valor<<"]->";
        //N.aristas->Imprimir();
    }
public:
    //Nodo():valor(0){}//, aristas(){}
    Nodo(int _valor=0, Nodo *_Sig):
        valor(_valor), Sig(_Sig){}
        
    void InsertarArista(int A)
    {
        cout<<"Incertando arista m8\n";
        Arista ar(A);
        cout<<ar;
        int trash=1;
        //Arista ari(A);
//        aristas->Insertar(ar,trash);   
        cout<<"done!\n";
    }
    
    Nodo operator=(const Nodo &N)
    {
        valor = N.valor;
       // aristas = N.aristas;
        Sig = N.Sig; 
        return *this;
    }
    
    bool operator>(const Nodo &N) const
    {
        return (valor>N.valor)? true : false;   
    }
    bool operator>=(const Nodo &N) const
    {
        return (valor>=N.valor)? true : false;   
    }
    bool operator<(const Nodo &N) const
    {
        return (valor<N.valor)? true : false;   
    }
    bool operator<=(const Nodo &N) const
    {
        return (valor<=N.valor)? true : false;   
    }
    bool operator==(const Nodo &N) const
    {
        return (valor==N.valor)? true : false;   
    }
    bool operator!=(const Nodo &N) const
    {
        return (valor!=N.valor)? true : false;   
    }
    void darValor(int _valor)
    {
        valor = _valor;   
    }
    void insArista(Nodo &N)
    {
        Nodo *aux =  this;
        while(aux->Sig){
            aux = aux->Sig;   
        } 
        aux->Sig = N;
        
    }
private:
    int valor;
    Nodo *Sig;
    Nodo *Primero;
    //Lista<Arista> aristas;
    
};

#endif
