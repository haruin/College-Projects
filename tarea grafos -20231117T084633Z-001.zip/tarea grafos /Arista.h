#ifndef _ARISTA_H
#define _ARISTA_H

//template<class Tipo> class Lista; 
//template<class Tipo>
class Arista{
  //  friend class Lista;
    friend class Grafo;
  //  friend class Nodo;
    friend ostream & operator<<(ostream &COUT,const Arista &N)
    {
        COUT<<"("<<N.valor<<")->";
    }
public:
    Arista(int _valor=0, Arista *_Sig=NULL):
        valor(_valor), Sig(_Sig){}
        
    Arista operator=(const Arista &N)
    {
        valor = N.valor;
        Sig = N.Sig; 
        return *this;
    }
    bool operator>(const Arista &N) const
    {
        return (valor>N.valor)? true : false;   
    }
    bool operator>=(const Arista &N) const
    {
        return (valor>=N.valor)? true : false;   
    }
    bool operator<(const Arista &N) const
    {
        return (valor<N.valor)? true : false;   
    }
    bool operator<=(const Arista &N) const
    {
        return (valor<=N.valor)? true : false;   
    }
    bool operator==(const Arista &N) const
    {
        return (valor==N.valor)? true : false;   
    }
    bool operator!=(const Arista &N) const
    {
        return (valor!=N.valor)? true : false;   
    }
private:
    int valor;
    Arista *Sig;
};

#endif
