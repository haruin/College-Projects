/*
  Name: ListaEnlazadaAscendente.cpp
  Author: Luis Roberto Alcazar Ortega
  Description: Programa que maneja Listas Enlazadas Ascendentes.
*/

#ifndef _LISTA_H
#define _LISTA_H

#include <cstdlib>
#include <iostream>

using namespace std;

template <class Tipo>
bool MenorQue(Tipo a,Tipo b){ return a<b; }
template <class Tipo>
bool Distinto(Tipo a, Tipo b){ return a!=b; }
template <class Tipo>
bool MayorQue(Tipo a,Tipo b){ return a>b; }

//******************************************************************************
class Excepcion{
public:
   Excepcion(const char *cadena){ strcpy(Msn,cadena); }
   const char *QuePasa(){ return Msn; }
private:
   char Msn[100];  
};
//******************************************************************************
template <class Tipo> class Lista;
template <class Tipo>
class Elemento{
	friend class Lista<Tipo>;
	friend class Grafo;
public:
    Elemento(Tipo _valor, Elemento<Tipo> *_Sig = NULL):
        valor(_valor), Sig(_Sig){cout<<"Elemento entered!\n";}
private:  
    Tipo valor;
    Elemento<Tipo> *Sig;    
};
//******************************************************************************
template <class Tipo>
class Lista{
    friend class Polinomio;
    friend class Grafo; 
    friend class Nodo;
public:
    Lista(): Primero(NULL){cout<<"Lista creada!\n";}
    Lista(const Lista<Tipo> &);
    ~Lista();
    Lista &operator=(const Lista<Tipo> &);
    bool ListaVacia(){   return !Primero;   }
    void Insertar(Tipo);
    bool Buscar(Tipo);
    Elemento<Tipo> *Buscar(Tipo,bool (Tipo, Tipo));
    void Eliminar(Tipo);
    void BorrarLista(){ while(!ListaVacia()) Eliminar(Primero->valor); }
    void Imprimir();
    
    void Insertar(Tipo &, int &);
    bool *Buscar(Tipo &,int &);
    Elemento<Tipo> *Buscar(Tipo &,bool (Tipo, Tipo), int &);
    void *Eliminar(Tipo *,int);
private:
    Elemento<Tipo> *Primero;   
};
//******************************************************************************
//Destructor.
template <typename Tipo>
Lista<Tipo>::~Lista()
{
    BorrarLista();
}
//******************************************************************************
//Constructor de copias.
template <typename Tipo>
Lista<Tipo>::Lista(const Lista<Tipo> &W)
{
    *this = W;
}
//******************************************************************************
//Sobrecarga del operador =
template <typename Tipo>
Lista<Tipo> &Lista<Tipo>::operator=(const Lista<Tipo> &W)
{
    if(this!=&W){
        BorrarLista();
        Elemento<Tipo> *auxW = W.Primero;
        while(auxW) {
	  		Insertar(auxW->valor);
			auxW=auxW->Sig;
        }
    }
    return *this;
}
/******************************************************************************
Funcion que agrega un elemento a la Lista.
Parametros: valor de cualquier tipo
Valor devuelto: 
*/
template <typename Tipo>
void Lista<Tipo>::Insertar(Tipo _valor)
{
    cout<<"Insertar entered!\n";
    int trash=1;
    Elemento<Tipo> *aux = Primero;
    cout<<"aux get!\n";
    Elemento<Tipo> *ant = Buscar(_valor,MenorQue,trash);
    cout<<"ant get!\n";
    if(ant==NULL) ant = Primero;
    cout<<"if ant done!\n";
    if(!ListaVacia() && ant->valor<=_valor) aux = ant->Sig;
    cout<<"segundo if done!\n";
    Elemento<Tipo> *nuevo;// = new Elemento<Tipo>(_valor, aux);
    nuevo->valor = _valor;
    //nuevo->Sig = aux;
    cout<<"nuevo get!\n";
    aux==Primero? Primero = nuevo : ant->Sig = nuevo;   
    cout<<"Insertar done!\n"; 
}
/******************************************************************************
Funcion que elimina un elemento de la Lista.
Parametros: El elemento a eliminar
Valor devuelto: 
*/
template <typename Tipo>
void Lista<Tipo>::Eliminar(Tipo _valor)
{
    if(Buscar(_valor)){
        Elemento<Tipo> *ant = Buscar(_valor,Distinto), *aux;
        if(ant==NULL){
            aux=Primero;
            Primero=Primero->Sig;   
        }else{
            aux = ant->Sig;
            ant->Sig = aux->Sig;  
        }
        delete aux;
    }
}
/******************************************************************************
Funcion que busca un elemento de la Lista.
Parametros: Elemento a buscar
Valor devuelto: Un indicador que dice si esta o no.
*/
template<class Tipo>
bool Lista<Tipo>::Buscar(Tipo _valor)
{
    if(ListaVacia()) return false;
    Elemento<Tipo> *aux = Buscar(_valor,Distinto);
    
    if(!aux) if(Primero->valor==_valor) return true;
    return (aux->Sig && aux->Sig->valor == _valor)? true: false;
}
/******************************************************************************
Funcion que busca un elemento de la Lista usando un determinado metodo.
Parametros: Elemento a buscar y el metodo a utilizar
Valor devuelto: el elemento anterior al que buscamos.
*/
template<class Tipo>
Elemento<Tipo> * Lista<Tipo>::Buscar(Tipo _valor, bool (*Comp)(Tipo,Tipo))
{
    Elemento<Tipo> *aux = Primero, *ant = NULL;
    while(aux && Comp(aux->valor,_valor)){
        ant = aux;
        aux = aux->Sig;
    }
    return ant; 
}
/******************************************************************************
Funcion que imprime la Lista.
Parametros: nada
Valor devuelto: 
*/
template <typename Tipo>
void Lista<Tipo>::Imprimir()
{
    if(ListaVacia())     cout<<"La Lista esta vacia!\n";
    else{
        Elemento<Tipo> *aux = Primero;
        while(aux){
        	cout<<aux->valor<<"\n";
        	aux = aux->Sig;
        }
        cout<<"\b\b\b "<<endl;
    }
}
//******************************************************************************
//SOBRECARGAS
/******************************************************************************
Funcion que agrega un elemento a la Lista.
Parametros: valor de cualquier tipo
Valor devuelto: 
*/
template <typename Tipo>
void Lista<Tipo>::Insertar(Tipo &_valor, int &trash)
{
    cout<<"Insertar entered...\n";
    Elemento<Tipo> *aux = Primero;
    cout<<"aux get!\n";
    Elemento<Tipo> *ant = Buscar(_valor,MenorQue,trash);
    cout<<"ant get!\n";
    cout<<"1/4\n";
    if(ant==NULL) ant = Primero;
    cout<<"2/4\n";
    if(!ListaVacia() && ant->valor<=_valor) aux = ant->Sig;
    cout<<"3/4\n";
    Elemento<Tipo> *nuevo = new Elemento<Tipo>(_valor, aux);
    cout<<"4/4\n";
    aux==Primero? Primero = nuevo : ant->Sig = nuevo;   
    cout<<"Insertar done!\n";
}
/******************************************************************************
Funcion que elimina un elemento de la Lista.
Parametros: El elemento a eliminar
Valor devuelto: 
*/
template <typename Tipo>
void *Lista<Tipo>::Eliminar(Tipo *_valor, int trash)
{
    if(Buscar(_valor)){
        Elemento<Tipo> *ant = Buscar(_valor,Distinto), *aux;
        if(ant==NULL){
            aux=Primero;
            Primero=Primero->Sig;   
        }else{
            aux = ant->Sig;
            ant->Sig = aux->Sig;  
        }
        delete aux;
    }
}
/******************************************************************************
Funcion que busca un elemento de la Lista.
Parametros: Elemento a buscar
Valor devuelto: Un indicador que dice si esta o no.
*/
template<class Tipo>
bool *Lista<Tipo>::Buscar(Tipo &_valor, int &trash)
{
    if(ListaVacia()) return false;
    Elemento<Tipo> *aux = Buscar(_valor,Distinto, trash);
    
    if(!aux) if(Primero->valor==_valor) return true;
    return (aux->Sig && aux->Sig->valor == _valor)? true: false;
}
/******************************************************************************
Funcion que busca un elemento de la Lista usando un determinado metodo.
Parametros: Elemento a buscar y el metodo a utilizar
Valor devuelto: el elemento anterior al que buscamos.
*/
template<class Tipo>
Elemento<Tipo> * Lista<Tipo>::Buscar(Tipo &_valor, bool (*Comp)(Tipo,Tipo), int &trash)
{
    Elemento<Tipo> *aux = Primero, *ant = NULL;
    while(aux && Comp(aux->valor,_valor)){
        ant = aux;
        aux = aux->Sig;
    }
    return ant; 
}

#endif
