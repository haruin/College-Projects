#include <cstdlib>
#include <iostream>

using namespace std;

//#include "NodoBETA.h"
//#include "Lista.h"
#include "Grafo2Beta.h"

//typedef Nodo<int> nodo;

int main()
{
    Grafo graf;
    Nodo n, a, b;
    int choice, valor, valor2;
    
    for(int i=0;i<5;i++){
        //cout<<"Dame valor m8: ";
        //cin>>valor;
        //n->darValor(valor);
        cin>>n;
        graf.Agregar(n);
        //graf.Agregar(valor);
        graf.Imprimir();
    }
    cout<<"Grafo:\n";
    graf.Imprimir();
    /*do{
        cout<<"Unir grafos? (0=No): ";
        cin>>choice;
        if(choice!=0){
            cout<<"Dame valor 1 m8: "; cin>>valor;
            cout<<"Dame valor 2 m8: "; cin>>valor2;
            graf.Unir(valor, valor2);
            
           // cin>>a;
           // cin>>b;
            //graf.Unir(a,b);
            
        }
        
    }while(choice!=0);
*/
    graf.Imprimir();

    system("pause");
    return 0;
}
